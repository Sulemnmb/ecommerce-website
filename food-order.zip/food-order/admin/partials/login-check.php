<?php
     //Authorization - Access Control
    //CHeck whether the user is logged in or not 
    if(!isset($_SESSION['user'])) //IF user session is not set
    {
        //user is not logged in
        //Redirect to login Page with message
        $_SESSION['no login message'] - "<div class='error'text-center'>please login to access admin panel.</div>";
        //Redirect to login Page
        header('location:'.SITEURL.'admin/login.php');
    }

?>