<?php

   //include constants.php file
   include('../config/constants.php');

  // 1. get the ID Admin to be deleted
   $id = $_GET['id'];

  // 2. create SQL Query to Delete Admin 
   $sql = "DELETE FROM tbl_admin WHERE id=$id";

   //execute the Query 
     $res = mysqli_query($conn,$sql);
      
     //checked whether the query executed successfully or not
     if($res==true)
     {
           //Query Executed successfully and Admin Deleted
           //echo "Admin Deleted";
           //create session variable to Display Message 
           $_SESSION['selete'] = "<div class='success'>Admin Deleted successfully.</div>";
           //Redirect to manage Admin page 
           header('location:'.SITEURL.'admin/manage-admin.php');
     }
     else
     {
         //failed to deleted Admin
         //echo "failed to Deleted Admin";
         $_SESSION['delete'] ="<div claas='error'>failed to delete Admin, Try Again Later.</div>";  
         header('location:'.SITEURL.'admin/manage-admin.php'); 
     }
  // 3. redirect to manage Admin paga with message (success/error)

?>