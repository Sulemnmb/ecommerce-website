 <!-- social Section Starts Here -->
 <section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="http//:www.facebook.com"> Suleman Muhammad <img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>

                <li>
                    <a href="http://www.instagram.com"> sooleman_bouba <img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>

                <li>
                    <a href="http//:www.twitter.com"> Suleman Buba <img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>

                <li>
                    
                    <ul>Email Us</ul>
                    <a href="http://www.email.com">sulemanmuhammadbuba@gmail.com<img src="https://img.icons8.com/fluent/48/000000/email.png"/></a>
                </li>

                <li>
                    <ul>Contact Us</ul>
                    <a href="http//:www.contact,com">0640724088/0698828252<img src="https://img.icons8.com/fluent/48/000000/call.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="#">Suleman/Ismail</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>